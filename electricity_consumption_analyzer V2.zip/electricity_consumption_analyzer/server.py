import json
import socket
from analyzer import analyze_payload

HOST = "127.0.0.1"
PORT = 5050
MAX_REQUEST_BYTES = 1_000_000
CLIENT_TIMEOUT = 10  # seconds a client may take to send its request


def receive_json_line(conn):
    """Read one newline-terminated JSON request, with a size limit."""
    chunks = bytearray()
    while len(chunks) <= MAX_REQUEST_BYTES:
        part = conn.recv(4096)
        if not part:
            break
        chunks.extend(part)
        if b"\n" in part:
            break
    if len(chunks) > MAX_REQUEST_BYTES:
        raise ValueError("Request is too large.")
    line = bytes(chunks).split(b"\n", 1)[0].strip()
    if not line:
        raise ValueError("Empty request.")
    return json.loads(line.decode("utf-8"))


def log_request(payload, result):
    """Print what the server received and how the FSM handled it."""
    appliances = payload.get("appliances") if isinstance(payload, dict) else None
    count = len(appliances) if isinstance(appliances, list) else 0
    print(f"  Request received : {count} appliance record(s)")
    for step in result.get("fsm", {}).get("transitions", []):
        print(f"  FSM transition   : {step['from']:<10} --{step['event']}--> {step['to']}")
    if result.get("ok"):
        print(f"  Result           : OK - {result['monthly_total_kwh']:.3f} kWh/month, "
              f"Rs {result['estimated_monthly_bill_inr']:.2f}")
    else:
        print(f"  Result           : ERROR - {result.get('error')}")


def handle_client(conn, address):
    """Serve one client; a bad request or dropped connection never stops the server."""
    print(f"\nConnected by {address[0]}:{address[1]}")
    with conn:
        conn.settimeout(CLIENT_TIMEOUT)
        payload = None
        try:
            payload = receive_json_line(conn)
            result = analyze_payload(payload)
        except TimeoutError:
            result = {"ok": False, "error": "Invalid request: timed out waiting for data."}
        except OSError as exc:  # e.g. connection reset: nobody is left to reply to
            print(f"  Connection error while reading request: {exc}")
            return
        except (ValueError, RecursionError) as exc:  # bad JSON, bad UTF-8, too large, too deeply nested
            result = {"ok": False, "error": f"Invalid request: {exc}"}
        except Exception as exc:  # unexpected bug: report it, keep serving other clients
            result = {"ok": False, "error": f"Internal server error ({type(exc).__name__})."}
        log_request(payload, result)
        try:
            conn.sendall(json.dumps(result).encode("utf-8") + b"\n")
        except OSError as exc:
            print(f"  Could not send response: {exc}")
            return
    print("  Response sent to client.")


def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(5)
        server.settimeout(1.0)  # lets Ctrl+C interrupt accept(), including on Windows
        print("=" * 60)
        print(" ELECTRICITY CONSUMPTION ANALYZER - TCP SERVER")
        print("=" * 60)
        print(f"Listening on {HOST}:{PORT}")
        print("Start client.py in another terminal. Press Ctrl+C to stop.")
        try:
            while True:
                try:
                    conn, address = server.accept()
                except TimeoutError:
                    continue
                handle_client(conn, address)
        except KeyboardInterrupt:
            print("\nServer stopped.")


if __name__ == "__main__":
    main()
