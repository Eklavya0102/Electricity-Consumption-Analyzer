import contextlib
import io
import json
import math
import socket
import struct
import threading
import time
import unittest

import client
import server
from analyzer import (
    MONTHLY_COST_FORMULA, AnalysisFSM, analyze_payload,
    days, hours_day, power_w, tariff,
)


class ElectricityAnalyzerTests(unittest.TestCase):
    def test_normal_usage(self):
        """Test 1 - normal usage: 10 W bulb for 5 h/day gives correct energy and bill."""
        payload = {
            "tariff": 8,
            "appliances": [{"name": "Bulb", "power_w": 10, "hours_per_day": 5}]
        }
        result = analyze_payload(payload)
        self.assertTrue(result["ok"])
        self.assertEqual(result["daily_total_kwh"], 0.05)
        self.assertEqual(result["monthly_total_kwh"], 1.5)
        self.assertEqual(result["estimated_monthly_bill_inr"], 12.0)
        self.assertEqual(result["fsm"]["final_state"], "COMPLETED")

    def test_high_consumption(self):
        """Test 2 - high consumption: 2000 W heater for 5 h/day is flagged as high usage."""
        payload = {
            "tariff": 8,
            "appliances": [{"name": "Heater", "power_w": 2000, "hours_per_day": 5}]
        }
        result = analyze_payload(payload)
        self.assertTrue(result["ok"])
        self.assertEqual(result["daily_total_kwh"], 10.0)
        self.assertEqual(result["monthly_total_kwh"], 300.0)
        self.assertEqual(result["estimated_monthly_bill_inr"], 2400.0)
        self.assertIn("Heater", result["high_consumption_appliances"])

    def test_invalid_hours(self):
        """Test 3 - invalid input: 30 hours/day is rejected and the FSM ends in ERROR."""
        payload = {
            "tariff": 8,
            "appliances": [{"name": "Fan", "power_w": 75, "hours_per_day": 30}]
        }
        result = analyze_payload(payload)
        self.assertFalse(result["ok"])
        self.assertIn("between 0 and 24", result["error"])
        self.assertEqual(result["fsm"]["final_state"], "ERROR")

    def test_rejects_non_finite_and_missing_values(self):
        """Validation - NaN, Infinity, huge integers, negatives and missing fields are rejected."""
        def one(**changes):
            return {"tariff": 8, "appliances": [{"name": "A", "power_w": 100, "hours_per_day": 2, **changes}]}
        bad_payloads = [  # (payload, text the validation error must contain)
            (json.loads('{"tariff": 8, "appliances": [{"name": "A", "power_w": Infinity, "hours_per_day": 2}]}'), "finite number"),
            (json.loads('{"tariff": 8, "appliances": [{"name": "A", "power_w": 100, "hours_per_day": NaN}]}'), "between 0 and 24"),
            (json.loads('{"tariff": NaN, "appliances": [{"name": "A", "power_w": 100, "hours_per_day": 2}]}'), "finite number"),
            (json.loads('{"tariff": Infinity, "appliances": [{"name": "A", "power_w": 100, "hours_per_day": 2}]}'), "finite number"),
            (json.loads('{"tariff": 8, "appliances": [{"name": "A", "power_w": 1' + "0" * 400 + ', "hours_per_day": 2}]}'), "finite number"),
            (one(hours_per_day=-1), "between 0 and 24"),
            (one(power_w=0), "greater than zero"),
            ({"tariff": -1, "appliances": one()["appliances"]}, "cannot be negative"),
            ({"tariff": 8, "appliances": [{"name": "A", "power_w": 100}]}, "needs name"),
            ({"tariff": 8, "appliances": []}, "non-empty list"),
        ]
        for payload, expected_text in bad_payloads:
            with self.subTest(payload=str(payload)[:60]):
                result = analyze_payload(payload)
                self.assertFalse(result["ok"])
                self.assertIn(expected_text, result["error"])
                self.assertEqual(result["fsm"]["states"], ["RECEIVED", "VALIDATING", "ERROR"])

    def test_result_too_large_is_rejected_in_analyzing_state(self):
        """Overflow - a finite input whose result overflows fails via ANALYZING -> ERROR."""
        result = analyze_payload({"tariff": 8, "appliances": [{"name": "A", "power_w": 1e308, "hours_per_day": 24}]})
        self.assertFalse(result["ok"])
        self.assertEqual(result["fsm"]["states"], ["RECEIVED", "VALIDATING", "ANALYZING", "ERROR"])
        self.assertEqual(result["fsm"]["transitions"][-1]["event"], "analysis_failure")


class FsmAndSymPyTests(unittest.TestCase):
    def test_fsm_successful_path_logs_state_event_state(self):
        """FSM - the success path logs (current state, input event, next state) for every step."""
        result = analyze_payload({"tariff": 8, "appliances": [{"name": "Bulb", "power_w": 10, "hours_per_day": 5}]})
        steps = [(t["from"], t["event"], t["to"]) for t in result["fsm"]["transitions"]]
        self.assertEqual(steps, [
            ("RECEIVED", "valid_data", "VALIDATING"),
            ("VALIDATING", "valid_records", "ANALYZING"),
            ("ANALYZING", "analysis_success", "COMPLETED"),
        ])

    def test_fsm_invalid_data_path_ends_in_error(self):
        """FSM - invalid records take VALIDATING -> ERROR."""
        result = analyze_payload({"tariff": 8, "appliances": [{"name": "Fan", "power_w": 75, "hours_per_day": 30}]})
        self.assertEqual(result["fsm"]["states"], ["RECEIVED", "VALIDATING", "ERROR"])
        self.assertEqual(result["fsm"]["transitions"][-1]["event"], "invalid_records")

    def test_fsm_rejects_invalid_transition(self):
        """FSM - an event that is not allowed in the current state raises an error."""
        fsm = AnalysisFSM()
        with self.assertRaises(RuntimeError):
            fsm.transition("analysis_success")  # not allowed while in RECEIVED
        self.assertEqual(fsm.state, "RECEIVED")  # state unchanged after the rejected event

    def test_sympy_formula_matches_numeric_calculation(self):
        """SymPy - substituting values into the symbolic cost formula equals plain arithmetic."""
        symbolic = MONTHLY_COST_FORMULA.subs({power_w: 2000, hours_day: 5, days: 30, tariff: 8})
        numeric = 2000 * 5 / 1000 * 30 * 8
        self.assertTrue(math.isclose(float(symbolic), numeric))
        self.assertEqual(str(MONTHLY_COST_FORMULA), "days*hours_day*power_w*tariff/1000")

    def test_sympy_check_is_reported_in_analysis(self):
        """SymPy - the analysis result includes a symbolic cross-check that agrees with the numbers."""
        result = analyze_payload({"tariff": 8, "appliances": [
            {"name": "Heater", "power_w": 2000, "hours_per_day": 5},
            {"name": "Bulb", "power_w": 10, "hours_per_day": 5},
        ]})
        check = result["symbolic_check"]
        self.assertTrue(check["matches_numeric"])
        self.assertEqual(check["monthly_energy_kwh"], result["monthly_total_kwh"])
        self.assertEqual(check["monthly_cost_inr"], result["estimated_monthly_bill_inr"])


class TcpClientServerTests(unittest.TestCase):
    """Real TCP sockets on 127.0.0.1 with an OS-chosen free port; the server runs in a thread."""

    VALID = {"tariff": 8, "appliances": [{"name": "Bulb", "power_w": 10, "hours_per_day": 5}]}

    def setUp(self):
        quiet = contextlib.redirect_stdout(io.StringIO())  # hide server log lines during tests
        quiet.__enter__()
        self.addCleanup(quiet.__exit__, None, None, None)
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listener.bind(("127.0.0.1", 0))
        self.listener.listen(5)
        self.listener.settimeout(0.2)  # short polling so the thread can notice the stop flag
        self.stop_requested = threading.Event()
        self.port = self.listener.getsockname()[1]
        self.server_errors = []
        thread = threading.Thread(target=self._serve, daemon=True)
        thread.start()
        self.addCleanup(self._stop_server, thread)

    def _serve(self):
        while not self.stop_requested.is_set():
            try:
                conn, address = self.listener.accept()
            except TimeoutError:
                continue
            except OSError:
                return
            try:
                server.handle_client(conn, address)
            except Exception as exc:  # handle_client must never raise
                self.server_errors.append(exc)

    def _stop_server(self, thread):
        self.stop_requested.set()
        thread.join(timeout=5)
        self.listener.close()
        self.assertEqual(self.server_errors, [])

    def _raw_exchange(self, chunks, delay=0.0, half_close=False):
        with socket.create_connection(("127.0.0.1", self.port), timeout=10) as sock:
            for chunk in chunks:
                sock.sendall(chunk)
                if delay:
                    time.sleep(delay)
            if half_close:
                sock.shutdown(socket.SHUT_WR)
            reply = bytearray()
            while b"\n" not in reply:
                part = sock.recv(4096)
                if not part:
                    break
                reply.extend(part)
        return json.loads(bytes(reply).decode("utf-8"))

    def test_client_server_round_trip(self):
        """TCP - the real client function sends data and receives a correct analysis."""
        result = client.request_analysis(self.VALID, "127.0.0.1", self.port)
        self.assertTrue(result["ok"])
        self.assertEqual(result["monthly_total_kwh"], 1.5)
        self.assertEqual(result["estimated_monthly_bill_inr"], 12.0)
        self.assertEqual(result["fsm"]["final_state"], "COMPLETED")

    def test_server_analyzes_the_data_it_receives(self):
        """TCP - different input gives different output (server is not returning fixed results)."""
        heater = {"tariff": 10, "appliances": [{"name": "Heater", "power_w": 2000, "hours_per_day": 5}]}
        result = client.request_analysis(heater, "127.0.0.1", self.port)
        self.assertEqual(result["monthly_total_kwh"], 300.0)
        self.assertEqual(result["estimated_monthly_bill_inr"], 3000.0)
        self.assertEqual(result["high_consumption_appliances"], ["Heater"])

    def test_fragmented_request_is_reassembled(self):
        """TCP framing - a request split across several send() calls is still read in full."""
        line = json.dumps(self.VALID).encode("utf-8") + b"\n"
        reply = self._raw_exchange([line[:7], line[7:25], line[25:]], delay=0.05)
        self.assertTrue(reply["ok"])
        self.assertEqual(reply["monthly_total_kwh"], 1.5)

    def test_malformed_and_incomplete_requests_get_error_replies(self):
        """TCP errors - bad JSON, truncated JSON, bad UTF-8 and empty input are answered with errors."""
        cases = [
            self._raw_exchange([b"{not json\n"]),
            self._raw_exchange([b'{"tariff": 8, "appl'], half_close=True),
            self._raw_exchange([b"\xff\xfe\n"]),
            self._raw_exchange([b"\n"]),
        ]
        for reply in cases:
            self.assertFalse(reply["ok"])
            self.assertIn("Invalid request", reply["error"])

    def test_server_survives_bad_clients_and_keeps_serving(self):
        """TCP robustness - nested JSON, huge integers and a dropped connection don't stop the server."""
        nested = self._raw_exchange([b"[" * 100000 + b"\n"])
        self.assertFalse(nested["ok"])
        huge = b'{"tariff": 8, "appliances": [{"name": "A", "power_w": 1' + b"0" * 400 + b', "hours_per_day": 2}]}\n'
        self.assertFalse(self._raw_exchange([huge])["ok"])
        # Abrupt reset: client sends a request, then closes with a TCP RST instead of waiting for the reply.
        sock = socket.create_connection(("127.0.0.1", self.port), timeout=10)
        sock.sendall(json.dumps(self.VALID).encode("utf-8") + b"\n")
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0))
        sock.close()
        # The server must still answer a normal request afterwards.
        result = client.request_analysis(self.VALID, "127.0.0.1", self.port)
        self.assertTrue(result["ok"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
