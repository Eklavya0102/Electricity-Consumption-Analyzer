import json
import socket

HOST = "127.0.0.1"
PORT = 5050

# Step 1: sample dataset (power in watts, usage in hours per day).
SAMPLE_DATA = {
    "tariff": 8.0,
    "appliances": [
        {"name": "LED Bulb", "power_w": 10, "hours_per_day": 6},
        {"name": "Ceiling Fan", "power_w": 75, "hours_per_day": 8},
        {"name": "Laptop", "power_w": 65, "hours_per_day": 5},
        {"name": "Refrigerator", "power_w": 150, "hours_per_day": 10},
        {"name": "Electric Heater", "power_w": 1000, "hours_per_day": 1},
    ],
}


def request_analysis(data, host=HOST, port=PORT, timeout=10):
    """Send one dataset to the server as a JSON line and return the decoded JSON reply."""
    request = json.dumps(data).encode("utf-8") + b"\n"
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
        client.settimeout(timeout)
        client.connect((host, port))
        client.sendall(request)
        chunks = bytearray()
        while b"\n" not in chunks:
            part = client.recv(4096)
            if not part:
                break
            chunks.extend(part)
    if not chunks:
        raise ConnectionError("Server closed the connection without a response.")
    return json.loads(bytes(chunks).split(b"\n", 1)[0].decode("utf-8"))


def main():
    print(f"Connecting to server at {HOST}:{PORT} ...")
    try:
        result = request_analysis(SAMPLE_DATA)
    except ConnectionRefusedError:
        print("Could not connect. Start server.py first.")
        return 1
    except (TimeoutError, OSError, ValueError) as exc:  # ValueError covers bad JSON from the server
        print(f"Communication error: {exc}")
        return 1
    print(f"TCP status: request sent ({len(SAMPLE_DATA['appliances'])} appliance records), response received.")
    print_report(result)
    return 0 if result.get("ok") else 1


def print_fsm_log(fsm):
    print("\n[1] FSM TRANSITION LOG")
    print(f"  {'Step':<6}{'Current state':<15}{'Input condition':<20}{'Next state'}")
    print("  " + "-" * 56)
    for number, step in enumerate(fsm.get("transitions", []), start=1):
        print(f"  {number:<6}{step['from']:<15}{step['event']:<20}{step['to']}")
    print(f"  Final state: {fsm['final_state']}")


def print_report(result):
    print("\n========== ELECTRICITY CONSUMPTION ANALYSIS ==========")
    print_fsm_log(result.get("fsm", {"final_state": "unknown"}))
    if not result.get("ok"):
        print("\nRESULT: ANALYSIS FAILED -", result.get("error", "Unknown error"))
        return

    print("\n[2] SYMBOLIC FORMULAS (SymPy)")
    for label, formula in result["symbolic_formulas"].items():
        print(f"  {label}: {formula}")
    check = result["symbolic_check"]
    print(f"  Formulas applied to the dataset: {check['monthly_energy_kwh']:.3f} kWh/month, "
          f"Rs {check['monthly_cost_inr']:.2f}/month")
    print(f"  Agrees with numeric calculation: {'YES' if check['matches_numeric'] else 'NO'}")

    print("\n[3] APPLIANCE BREAKDOWN")
    print(f"  {'Appliance':<18}{'Power (W)':>10}{'Hours/day':>11}{'Daily kWh':>12}{'Monthly kWh':>14}")
    print("  " + "-" * 65)
    for a in result["appliances"]:
        print(f"  {a['name']:<18}{a['power_w']:>10.0f}{a['hours_per_day']:>11.1f}"
              f"{a['daily_kwh']:>12.3f}{a['monthly_kwh']:>14.3f}")

    print("\n[4] SUMMARY")
    print(f"  Active appliances:         {result['active_appliance_count']}")
    print(f"  Total daily consumption:   {result['daily_total_kwh']:.3f} kWh")
    print(f"  Estimated monthly usage:   {result['monthly_total_kwh']:.3f} kWh")
    print(f"  Tariff:                    Rs {result['tariff_inr_per_kwh']:.2f}/kWh")
    print(f"  Estimated monthly bill:    Rs {result['estimated_monthly_bill_inr']:.2f}")
    print("  Appliances using >= 30 kWh/month:", ", ".join(result["high_consumption_appliances"]) or "None")
    print("\nNote:", result["note"])
    print(f"\nRESULT: ANALYSIS COMPLETED - {result['monthly_total_kwh']:.3f} kWh/month, "
          f"Rs {result['estimated_monthly_bill_inr']:.2f}/month")


if __name__ == "__main__":
    raise SystemExit(main())
