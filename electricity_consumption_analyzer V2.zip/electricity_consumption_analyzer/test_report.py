"""Readable, detailed test report for the Electricity Consumption Analyzer."""
import os
import sys

from analyzer import analyze_payload

# Colours 
USE_COLOR = sys.stdout.isatty() and "NO_COLOR" not in os.environ
GREEN = "\033[92m" if USE_COLOR else ""
RED = "\033[91m" if USE_COLOR else ""
CYAN = "\033[96m" if USE_COLOR else ""
YELLOW = "\033[93m" if USE_COLOR else ""
RESET = "\033[0m" if USE_COLOR else ""
WIDTH = 72


def line(char="─"):
    print(char * WIDTH)


def show_test(number, title, description, payload, checks):
    print()
    line("═")
    print(f" TEST CASE {number}: {title}")
    line("═")
    print(f"Purpose: {description}")
    print("\nInput data:")
    for appliance in payload.get("appliances", []):
        print(
            f"  • {appliance.get('name', '<unnamed>')}: "
            f"{appliance.get('power_w', '?')} W, "
            f"{appliance.get('hours_per_day', '?')} hour(s)/day"
        )
    print(f"  • Tariff: ₹{payload.get('tariff', 8)}/kWh")

    result = analyze_payload(payload)
    print("\nExpected vs Actual:")
    passed = True
    for label, expected, check in checks:
        actual, ok = check(result)
        passed = passed and ok
        status = f"{GREEN}PASS{RESET}" if ok else f"{RED}FAIL{RESET}"
        print(f"  {label}")
        print(f"    Expected: {expected}")
        print(f"    Actual:   {actual}")
        print(f"    Status:   {status}")

    fsm = result.get("fsm", {})
    print("\nFSM execution:")
    print("  " + " -> ".join(fsm.get("states", ["Not available"])))
    print(f"  Final state: {fsm.get('final_state', 'Not available')}")

    overall = f"{GREEN}PASS{RESET}" if passed else f"{RED}FAIL{RESET}"
    print(f"\nTest case result: {overall}")
    return passed


def main():
    print()
    line("═")
    print("          ELECTRICITY CONSUMPTION ANALYZER")
    print("                  TEST REPORT")
    line("═")
    print("Billing assumption: 30 days, flat tariff of ₹8/kWh unless specified")
    results = []

    normal = {
        "tariff": 8,
        "appliances": [{"name": "Bulb", "power_w": 10, "hours_per_day": 5}],
    }
    results.append(show_test(
        1,
        "Normal Electricity Consumption",
        "Verify daily energy, monthly energy, and bill for an ordinary appliance.",
        normal,
        [
            ("Daily consumption", "0.05 kWh", lambda r: (
                f"{r.get('daily_total_kwh')} kWh" if r.get("ok") else r.get("error"),
                r.get("ok") and r.get("daily_total_kwh") == 0.05
            )),
            ("Monthly consumption", "1.5 kWh", lambda r: (
                f"{r.get('monthly_total_kwh')} kWh" if r.get("ok") else r.get("error"),
                r.get("ok") and r.get("monthly_total_kwh") == 1.5
            )),
            ("Estimated bill", "₹12.00", lambda r: (
                f"₹{r.get('estimated_monthly_bill_inr'):.2f}" if r.get("ok") else r.get("error"),
                r.get("ok") and r.get("estimated_monthly_bill_inr") == 12.0
            )),
            ("FSM final state", "COMPLETED", lambda r: (
                r.get("fsm", {}).get("final_state"),
                r.get("fsm", {}).get("final_state") == "COMPLETED"
            )),
        ],
    ))

    high = {
        "tariff": 8,
        "appliances": [{"name": "Heater", "power_w": 2000, "hours_per_day": 5}],
    }
    results.append(show_test(
        2,
        "High Electricity Consumption",
        "Check a high-power appliance and verify it is flagged for attention.",
        high,
        [
            ("Daily consumption", "10.0 kWh", lambda r: (
                f"{r.get('daily_total_kwh')} kWh" if r.get("ok") else r.get("error"),
                r.get("ok") and r.get("daily_total_kwh") == 10.0
            )),
            ("Monthly consumption", "300.0 kWh", lambda r: (
                f"{r.get('monthly_total_kwh')} kWh" if r.get("ok") else r.get("error"),
                r.get("ok") and r.get("monthly_total_kwh") == 300.0
            )),
            ("Estimated bill", "₹2400.00", lambda r: (
                f"₹{r.get('estimated_monthly_bill_inr'):.2f}" if r.get("ok") else r.get("error"),
                r.get("ok") and r.get("estimated_monthly_bill_inr") == 2400.0
            )),
            ("High-consumption warning", "Heater is flagged", lambda r: (
                ", ".join(r.get("high_consumption_appliances", [])) or "No appliance flagged",
                r.get("ok") and "Heater" in r.get("high_consumption_appliances", [])
            )),
        ],
    ))

    invalid = {
        "tariff": 8,
        "appliances": [{"name": "Fan", "power_w": 75, "hours_per_day": 30}],
    }
    results.append(show_test(
        3,
        "Invalid Usage Input",
        "Ensure usage above 24 hours/day is rejected and FSM enters ERROR.",
        invalid,
        [
            ("Input acceptance", "Rejected (ok = False)", lambda r: (
                f"Rejected (ok = {r.get('ok')})" if not r.get("ok") else "Unexpectedly accepted",
                r.get("ok") is False
            )),
            ("Validation message", "Mentions allowed range 0–24", lambda r: (
                r.get("error", "No error message"),
                not r.get("ok") and "between 0 and 24" in r.get("error", "")
            )),
            ("FSM final state", "ERROR", lambda r: (
                r.get("fsm", {}).get("final_state"),
                r.get("fsm", {}).get("final_state") == "ERROR"
            )),
        ],
    ))

    passed = sum(results)
    failed = len(results) - passed
    print()
    line("═")
    print("                         FINAL SUMMARY")
    line("═")
    print(f"  Total test cases : {len(results)}")
    print(f"  {GREEN}Passed           : {passed}{RESET}")
    print(f"  {RED}Failed           : {failed}{RESET}")
    rate = (passed / len(results) * 100) if results else 0
    print(f"  Pass rate        : {rate:.1f}%")
    print(f"  Overall status   : {'ALL TESTS PASSED' if failed == 0 else 'SOME TESTS FAILED'}")
    line("═")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
