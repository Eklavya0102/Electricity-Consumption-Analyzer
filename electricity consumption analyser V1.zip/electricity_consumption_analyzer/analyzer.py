"""Core analysis logic for the Electricity Consumption Analyzer."""
from functools import reduce
from sympy import symbols, simplify

POWER_TO_KW = 1000
DAYS_PER_MONTH = 30
DEFAULT_TARIFF = 8.0  # INR per kWh; demonstration rate only

# Symbolic Computing (SymPy): derive energy and cost formulas.
power_w, hours_day, days, tariff = symbols("power_w hours_day days tariff", nonnegative=True)
DAILY_ENERGY_FORMULA = simplify(power_w * hours_day / POWER_TO_KW)
MONTHLY_ENERGY_FORMULA = simplify(DAILY_ENERGY_FORMULA * days)
MONTHLY_COST_FORMULA = simplify(MONTHLY_ENERGY_FORMULA * tariff)


class AnalysisError(ValueError):
    """Raised when the submitted electricity data is invalid."""


class AnalysisFSM:
    """A small FSM that records the analysis workflow."""
    TRANSITIONS = {
        "RECEIVED": {"valid_data": "VALIDATING", "invalid_payload": "ERROR"},
        "VALIDATING": {"valid_records": "ANALYZING", "invalid_records": "ERROR"},
        "ANALYZING": {"analysis_success": "COMPLETED", "analysis_failure": "ERROR"},
        "COMPLETED": {},
        "ERROR": {},
    }

    def __init__(self):
        self.state = "RECEIVED"
        self.history = [self.state]

    def transition(self, event):
        next_state = self.TRANSITIONS.get(self.state, {}).get(event)
        if next_state is None:
            raise RuntimeError(f"Invalid FSM transition: {self.state} + {event}")
        self.state = next_state
        self.history.append(self.state)


def validate_payload(payload):
    """Validate the request structure and every appliance record."""
    if not isinstance(payload, dict):
        raise AnalysisError("Payload must be a JSON object.")
    appliances = payload.get("appliances")
    if not isinstance(appliances, list) or not appliances:
        raise AnalysisError("'appliances' must be a non-empty list.")

    tariff_value = payload.get("tariff", DEFAULT_TARIFF)
    if isinstance(tariff_value, bool) or not isinstance(tariff_value, (int, float)):
        raise AnalysisError("Tariff must be a number.")
    if tariff_value < 0:
        raise AnalysisError("Tariff cannot be negative.")

    cleaned = []
    required = ("name", "power_w", "hours_per_day")
    for index, item in enumerate(appliances, start=1):
        if not isinstance(item, dict):
            raise AnalysisError(f"Appliance #{index} must be a JSON object.")
        if any(key not in item for key in required):
            raise AnalysisError(f"Appliance #{index} needs name, power_w, and hours_per_day.")
        name = item["name"]
        power = item["power_w"]
        hours = item["hours_per_day"]
        if not isinstance(name, str) or not name.strip():
            raise AnalysisError(f"Appliance #{index}: name must be a non-empty string.")
        if isinstance(power, bool) or not isinstance(power, (int, float)) or power <= 0:
            raise AnalysisError(f"Appliance '{name}': power_w must be greater than zero.")
        if isinstance(hours, bool) or not isinstance(hours, (int, float)) or not 0 <= hours <= 24:
            raise AnalysisError(f"Appliance '{name}': hours_per_day must be between 0 and 24.")
        cleaned.append({
            "name": name.strip(),
            "power_w": float(power),
            "hours_per_day": float(hours),
        })
    return cleaned, float(tariff_value)


def analyze_payload(payload):
    """Run validation, FSM transitions, functional processing, and SymPy calculations."""
    fsm = AnalysisFSM()
    try:
        fsm.transition("valid_data")
        appliances, tariff_value = validate_payload(payload)
        fsm.transition("valid_records")

        # Functional programming concept 1: map() transforms each record.
        enriched = list(map(
            lambda a: {
                **a,
                "daily_kwh": (a["power_w"] * a["hours_per_day"]) / POWER_TO_KW,
            },
            appliances
        ))

        # Functional programming concept 2: filter() selects appliances with meaningful usage.
        active = list(filter(lambda a: a["hours_per_day"] > 0, enriched))

        # Functional programming concept 3: reduce() combines daily usage into one total.
        daily_total = reduce(lambda total, a: total + a["daily_kwh"], active, 0.0)

        # Functional programming concept 4: list comprehension creates monthly per-appliance details.
        details = [
            {
                "name": a["name"],
                "power_w": a["power_w"],
                "hours_per_day": a["hours_per_day"],
                "daily_kwh": round(a["daily_kwh"], 3),
                "monthly_kwh": round(a["daily_kwh"] * DAYS_PER_MONTH, 3),
            }
            for a in enriched
        ]

        fsm.transition("analysis_success")
        monthly_total = daily_total * DAYS_PER_MONTH
        monthly_cost = monthly_total * tariff_value

        return {
            "ok": True,
            "message": "Analysis completed successfully.",
            "fsm": {"states": fsm.history, "final_state": fsm.state},
            "symbolic_formulas": {
                "daily_energy_kwh": str(DAILY_ENERGY_FORMULA),
                "monthly_energy_kwh": str(MONTHLY_ENERGY_FORMULA),
                "monthly_cost_inr": str(MONTHLY_COST_FORMULA),
            },
            "tariff_inr_per_kwh": tariff_value,
            "appliances": details,
            "active_appliance_count": len(active),
            "daily_total_kwh": round(daily_total, 3),
            "monthly_total_kwh": round(monthly_total, 3),
            "estimated_monthly_bill_inr": round(monthly_cost, 2),
            "high_consumption_appliances": [
                a["name"] for a in details if a["monthly_kwh"] >= 30
            ],
            "note": "Estimate only: assumes 30 days and a flat tariff; actual utility bills may use slabs, fees, and taxes."
        }
    except (AnalysisError, RuntimeError) as exc:
        if fsm.state not in ("ERROR", "COMPLETED"):
            # Follow the defined error transition for validation/analysis failures.
            event = "invalid_records" if fsm.state == "VALIDATING" else (
                "analysis_failure" if fsm.state == "ANALYZING" else "invalid_payload"
            )
            try:
                fsm.transition(event)
            except RuntimeError:
                pass
        return {
            "ok": False,
            "error": str(exc),
            "fsm": {"states": fsm.history, "final_state": fsm.state},
        }
