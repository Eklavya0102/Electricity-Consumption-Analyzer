"""Three required test cases for the core analysis (no TCP server needed)."""
import unittest
from analyzer import analyze_payload


class ElectricityAnalyzerTests(unittest.TestCase):
    def test_normal_usage(self):
        payload = {
            "tariff": 8,
            "appliances": [{"name": "Bulb", "power_w": 10, "hours_per_day": 5}]
        }
        result = analyze_payload(payload)
        self.assertTrue(result["ok"])
        self.assertEqual(result["daily_total_kwh"], 0.05)
        self.assertEqual(result["monthly_total_kwh"], 1.5)
        self.assertEqual(result["estimated_monthly_bill_inr"], 12.0)
        self.assertEqual(result["fsm"]["final_state"], "COMPLETED")

    def test_high_consumption(self):
        payload = {
            "tariff": 8,
            "appliances": [{"name": "Heater", "power_w": 2000, "hours_per_day": 5}]
        }
        result = analyze_payload(payload)
        self.assertTrue(result["ok"])
        self.assertEqual(result["daily_total_kwh"], 10.0)
        self.assertEqual(result["monthly_total_kwh"], 300.0)
        self.assertEqual(result["estimated_monthly_bill_inr"], 2400.0)
        self.assertIn("Heater", result["high_consumption_appliances"])

    def test_invalid_hours(self):
        payload = {
            "tariff": 8,
            "appliances": [{"name": "Fan", "power_w": 75, "hours_per_day": 30}]
        }
        result = analyze_payload(payload)
        self.assertFalse(result["ok"])
        self.assertIn("between 0 and 24", result["error"])
        self.assertEqual(result["fsm"]["final_state"], "ERROR")


if __name__ == "__main__":
    unittest.main(verbosity=2)
