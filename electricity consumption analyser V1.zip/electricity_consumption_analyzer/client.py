"""TCP client with a small sample electricity-consumption dataset."""
import json
import socket

HOST = "127.0.0.1"
PORT = 5050

# Step 1: sample dataset (power in watts, usage in hours per day).
SAMPLE_DATA = {
    "tariff": 8.0,
    "appliances": [
        {"name": "LED Bulb", "power_w": 10, "hours_per_day": 6},
        {"name": "Ceiling Fan", "power_w": 75, "hours_per_day": 8},
        {"name": "Laptop", "power_w": 65, "hours_per_day": 5},
        {"name": "Refrigerator", "power_w": 150, "hours_per_day": 10},
        {"name": "Electric Heater", "power_w": 1000, "hours_per_day": 1},
    ],
}


def main():
    request = json.dumps(SAMPLE_DATA).encode("utf-8") + b"\n"
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
            client.settimeout(10)
            client.connect((HOST, PORT))
            client.sendall(request)
            chunks = bytearray()
            while b"\n" not in chunks:
                part = client.recv(4096)
                if not part:
                    break
                chunks.extend(part)
        if not chunks:
            print("Server closed the connection without a response.")
            return
        result = json.loads(bytes(chunks).split(b"\n", 1)[0].decode("utf-8"))
        print_report(result)
    except ConnectionRefusedError:
        print("Could not connect. Start server.py first.")
    except (TimeoutError, OSError, json.JSONDecodeError) as exc:
        print(f"Communication error: {exc}")


def print_report(result):
    print("\n========== ELECTRICITY CONSUMPTION ANALYSIS ==========")
    if not result.get("ok"):
        print("Analysis failed:", result.get("error", "Unknown error"))
        if result.get("fsm"):
            print("FSM:", " -> ".join(result["fsm"]["states"]))
        return

    print("FSM:", " -> ".join(result["fsm"]["states"]))
    print("\nSymPy-derived formulas:")
    for label, formula in result["symbolic_formulas"].items():
        print(f"  {label}: {formula}")

    print("\nAppliance breakdown:")
    print(f"{'Appliance':<20}{'Daily kWh':>12}{'Monthly kWh':>15}")
    print("-" * 47)
    for appliance in result["appliances"]:
        print(f"{appliance['name']:<20}{appliance['daily_kwh']:>12.3f}{appliance['monthly_kwh']:>15.3f}")

    print("\nActive appliances:", result["active_appliance_count"])
    print(f"Total daily consumption:   {result['daily_total_kwh']:.3f} kWh")
    print(f"Estimated monthly usage:   {result['monthly_total_kwh']:.3f} kWh")
    print(f"Tariff:                    Rs {result['tariff_inr_per_kwh']:.2f}/kWh")
    print(f"Estimated monthly bill:    Rs {result['estimated_monthly_bill_inr']:.2f}")
    print("Appliances using >= 30 kWh/month:", ", ".join(result["high_consumption_appliances"]) or "None")
    print("\nNote:", result["note"])


if __name__ == "__main__":
    main()
