# Electricity Consumption Analyzer

A small Python application demonstrating:
- Functional Programming: `map()`, `filter()`, `reduce()`, `lambda`, and list comprehension.
- TCP Client–Server Programming: Python `socket` module.
- Finite State Machine (FSM): `RECEIVED`, `VALIDATING`, `ANALYZING`, `COMPLETED`, and `ERROR`.
- Symbolic Computing: SymPy expresses the energy and monthly-cost formulas.
- Testing: three automated test cases.

## Files

- `client.py` — sends the sample dataset and displays the report.
- `server.py` — accepts TCP requests and returns analysis as JSON.
- `analyzer.py` — validation, FSM, functional processing, and SymPy formulas.
- `test_analyzer.py` — three automated unit tests.
- `test_report.py` — detailed formatted test report for demonstration.
- `requirements.txt` — SymPy dependency.

## Requirements

Python 3.10+ recommended.

## Setup (Windows PowerShell or Command Prompt)

1. Open a terminal in this project folder.
2. Create a virtual environment (optional but recommended):

   ```bash
   python -m venv .venv
   ```

3. Activate it:

   PowerShell:
   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

   Command Prompt:
   ```bat
   .venv\Scripts\activate.bat
   ```

4. Install the dependency:

   ```bash
   python -m pip install -r requirements.txt
   ```

## Run the application

Open **two terminal windows** in the project folder. Activate the virtual environment in both if you created one.

Terminal 1 — start the server:
```bash
python server.py
```

Terminal 2 — start the client:
```bash
python client.py
```

The client sends the sample appliance dataset to the server over TCP. The server validates and analyzes it, then sends the JSON report back to the client. Use `Ctrl+C` in the server terminal to stop the server.

The server binds to `127.0.0.1`, so this example is intended for client and server on the same computer. For computers on a shared network, configure a trusted server IP and firewall deliberately; do not expose this demo server to the public internet.

## Run the tests

For a detailed, presentation-friendly report with inputs, expected results, actual results, FSM traces, and a final pass/fail summary, run:

```bash
python test_report.py
```

For the standard automated unit-test runner, also run:

```bash
python -m unittest -v test_analyzer.py
```

Expected result: all 3 test cases pass.

## FSM states and transitions

| Current state | Input/condition | Next state |
|---|---|---|
| `RECEIVED` | JSON payload received | `VALIDATING` |
| `RECEIVED` | Invalid payload event | `ERROR` |
| `VALIDATING` | All records valid | `ANALYZING` |
| `VALIDATING` | Invalid record | `ERROR` |
| `ANALYZING` | Calculations succeed | `COMPLETED` |
| `ANALYZING` | Calculation failure | `ERROR` |

The successful path is `RECEIVED → VALIDATING → ANALYZING → COMPLETED`.

## Symbolic calculation

SymPy defines the symbols and derives these expressions:

- Daily energy (kWh): `power_w * hours_day / 1000`
- Monthly energy (kWh): `power_w * hours_day * days / 1000`
- Monthly bill (INR): `power_w * hours_day * days * tariff / 1000`

The example assumes 30 days and a flat tariff of ₹8/kWh. These are demonstration assumptions, not a utility bill quote. Real tariffs may include slabs, fixed charges, taxes, and other adjustments.

## Test cases and expected results

| Test | Input | Expected result |
|---|---|---|
| 1. Normal usage | 10 W bulb, 5 h/day, ₹8/kWh | 0.05 kWh/day, 1.5 kWh/month, ₹12/month |
| 2. High consumption | 2000 W heater, 5 h/day, ₹8/kWh | 10 kWh/day, 300 kWh/month, ₹2400/month; heater flagged |
| 3. Invalid data | Fan usage = 30 h/day | Rejected with validation error; FSM ends in `ERROR` |

## Limitations

This is an educational prototype using sample data and a flat tariff. It does not connect to a smart meter or utility provider. The TCP service is a local classroom demo, not a production-hardened server.
