"""TCP server for the Electricity Consumption Analyzer."""
import json
import socket
from analyzer import analyze_payload

HOST = "127.0.0.1"
PORT = 5050
MAX_REQUEST_BYTES = 1_000_000


def receive_json_line(conn):
    """Read one newline-terminated JSON request, with a size limit."""
    chunks = bytearray()
    while len(chunks) <= MAX_REQUEST_BYTES:
        part = conn.recv(4096)
        if not part:
            break
        chunks.extend(part)
        if b"\n" in part:
            break
    if len(chunks) > MAX_REQUEST_BYTES:
        raise ValueError("Request is too large.")
    line = bytes(chunks).split(b"\n", 1)[0].strip()
    if not line:
        raise ValueError("Empty request.")
    return json.loads(line.decode("utf-8"))


def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(5)
        print(f"Electricity Analyzer server listening on {HOST}:{PORT}")
        print("Start client.py in another terminal. Press Ctrl+C to stop.")
        while True:
            conn, address = server.accept()
            with conn:
                print(f"\nConnected by {address}")
                try:
                    payload = receive_json_line(conn)
                    result = analyze_payload(payload)
                except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                    result = {"ok": False, "error": f"Invalid request: {exc}"}
                response = json.dumps(result).encode("utf-8") + b"\n"
                conn.sendall(response)
                print("Sent analysis response.")


if __name__ == "__main__":
    main()
